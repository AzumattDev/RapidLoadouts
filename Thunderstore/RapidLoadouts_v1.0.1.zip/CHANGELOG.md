| `Version` | `Update Notes`       |
|-----------|----------------------|
| 1.0.1     | - Auga compatibility |
| 1.0.0     | - Initial Release    |