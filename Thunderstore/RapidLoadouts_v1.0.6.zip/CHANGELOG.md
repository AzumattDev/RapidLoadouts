| `Version` | `Update Notes`                                                                                                                                   |
|-----------|--------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.0.6     | - Forgot about some code that was in there. Used the code to pre-generate the file so now all vanilla itemsets are in the file and configurable. |
| 1.0.5     | - Recompile for Ashlands.                                                                                                                        |
| 1.0.4     | - No one said it was broken, but it's fixed now. Figured it out in my own testing :D                                                             |
| 1.0.3     | - Update for Valheim 0.217.22                                                                                                                    |
| 1.0.2     | - Update for Valheim version (Hildir)                                                                                                            |
| 1.0.1     | - Auga compatibility                                                                                                                             |
| 1.0.0     | - Initial Release                                                                                                                                |